//
//  ViewController.m
//  YHTReachability
//
//  Created by 于海涛 on 16/7/23.
//  Copyright © 2016年 于海涛. All rights reserved.
//

#import "ViewController.h"
#import "YHTReachability.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [YHTReachability reachabilityChanged];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
